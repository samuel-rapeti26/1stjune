import axios from "axios";

export const api = axios.create({
  withCredentials: true,
  baseURL: "http://localhost:2000",
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
});
