import React from "react";
import { useState } from "react";

const TemplateOne = () => {
  const [templateFields, setTemplateFields] = useState({
    age: {
      value: "",
      active: false,
    },
    race: {
      value: "",
      active: false,
    },
  });
  return (
    <div className="flex flex-col gap-2">
      <span>
        The patient is a{" "}
        {templateFields.age.active ? (
          <input
            placeholder="Click or tap here to enter text"
            value={templateFields.age.value}
            className="w-12 shadow-lg"
            onChange={(e) =>
              setTemplateFields({
                ...templateFields,
                age: { value: e.target.value, active: true },
              })
            }
            onBlur={() =>
              setTemplateFields({
                ...templateFields,
                age: { value: templateFields.age.value, active: false },
              })
            }
          />
        ) : templateFields.age.value === "" ? (
          <span
            className="cursor-pointer"
            onClick={() =>
              setTemplateFields({
                ...templateFields,
                age: { value: templateFields.age.value, active: true },
              })
            }
          >
            Click here to add text
          </span>
        ) : (
          <span
            className="cursor-pointer text-lime-700 font-semibold bg-gray-300 px-2"
            onClick={() =>
              setTemplateFields({
                ...templateFields,
                age: { value: templateFields.age.value, active: true },
              })
            }
          >
            {templateFields.age.value}
          </span>
        )}
        . year-old{" "}
        {templateFields.race.active ? (
          <select
            value={templateFields.race.value}
            onChange={(e) => {
              setTemplateFields({
                ...templateFields,
                race: {
                  value: e.target.value,
                  active: false,
                },
              });
              console.log("---------------------------------------");
              console.log(e.target.value);
              console.log(templateFields);
            }}
          >
            <option value="Caucasian">Caucasian</option>
            <option value="white">white</option>
            <option value="brown">brown</option>
            <option value="black">black</option>
            <option value="light">light</option>
          </select>
        ) : templateFields.race.value === "" ? (
          <span
            className="cursor-pointer"
            onClick={() => {
              setTemplateFields({
                ...templateFields,
                race: {
                  value: templateFields.race.value,
                  active: true,
                },
              });
              console.log(templateFields);
            }}
          >
            choose race
          </span>
        ) : (
          <span
            className="cursor-pointer text-lime-700 font-semibold bg-gray-300 px-2"
            onClick={(e) => {
              setTemplateFields({
                ...templateFields,
                race: {
                  value: templateFields.race.value,
                  active: true,
                },
              });
              console.log(templateFields);
            }}
          >
            {templateFields.race.value}
          </span>
        )}{" "}
        Male with chronic pain syndrome presents for Choose an item.. Patient is
        right hand dominant. Currently, retired .
      </span>
    </div>
  );
};

export default TemplateOne;
