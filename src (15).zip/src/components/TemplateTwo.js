import React, { useState, useRef } from "react";

const TemplateTwo = () => {
  const [templateFields, setTemplateFields] = useState({
    age: {
      value: "",
      active: false,
      type: "input",
    },
    race: {
      value: "",
      active: false,
      type: "select",
      options: ["Caucasian", "white", "brown", "black", "light"],
    },
    male: {
      value: "",
      active: false,
      type: "select",
      options: ["Male", "Female"],
    },
    // Add more fields here...
  });

  const InputFieldComponent = ({ field, fieldName }) => {
    const isActive = field.active;
    const value = field.value;
    const inputRef = useRef(null);

    const handleFocus = () => {
      setTemplateFields({
        ...templateFields,
        [fieldName]: { ...field, active: true },
      });
    };

    const handleBlur = () => {
      setTemplateFields({
        ...templateFields,
        [fieldName]: { ...field, active: false },
      });
    };

    const handleChange = (e) => {
      setTemplateFields({
        ...templateFields,
        [fieldName]: { ...field, value: e.target.value },
      });
    };

    if (isActive) {
      return (
        <input
          ref={inputRef}
          placeholder="Click or tap here to enter text"
          value={value}
          className="w-12 shadow-lg"
          onChange={handleChange}
          onBlur={handleBlur}
          autoFocus
        />
      );
    }

    return (
      <span
        className={`cursor-pointer ${
          value ? "text-lime-700 font-semibold bg-gray-300 px-2" : ""
        }`}
        onClick={handleFocus}
      >
        {value || `Click here to add ${fieldName}`}
      </span>
    );
  };
  const SelectFieldComponent = ({ field, fieldName, onClick }) => {
    const isActive = field.active;
    const value = field.value;

    return (
      <span
        className={`cursor-pointer ${
          value ? "text-lime-700 font-semibold bg-gray-300 px-2" : ""
        }`}
        onClick={onClick}
      >
        {isActive
          ? renderField(fieldName)
          : value || `Click here to add ${fieldName}`}
      </span>
    );
  };
  const renderField = (fieldName) => {
    const field = templateFields[fieldName];

    if (field.type === "select") {
      return (
        <select
          value={field.value}
          onClick={(e) => e.stopPropagation()} // Prevent event propagation
          onChange={(e) =>
            setTemplateFields({
              ...templateFields,
              [fieldName]: { ...field, value: e.target.value, active: false },
            })
          }
        >
          {field.options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      );
    }

    return null;
  };

  return (
    <div>
      <div className="flex flex-col gap-2">
        <span>
          The patient is a{" "}
          <InputFieldComponent field={templateFields.age} fieldName="age" />
          year-old.{" "}
          <SelectFieldComponent
            field={templateFields.race}
            fieldName="race"
            onClick={() =>
              setTemplateFields({
                ...templateFields,
                race: { ...templateFields.race, active: true },
              })
            }
          />
          {templateFields.male.active ? (
            renderField("male")
          ) : (
            <SelectFieldComponent
              field={templateFields.male}
              fieldName="male"
              onClick={() =>
                setTemplateFields({
                  ...templateFields,
                  male: { ...templateFields.male, active: true },
                })
              }
            />
          )}
          with chronic pain syndrome presents for Choose an item.. Patient is
          right hand dominant. Currently, retired .
        </span>
        <span>
          The primary cause of pain is musculoskeletal disorders due to Lyme
          disease, pelvic floor myalgia (levator ani spasm),
          <SelectFieldComponent
            field={templateFields.age}
            fieldName="age"
            onClick={() =>
              setTemplateFields({
                ...templateFields,
                age: { ...templateFields.age, active: true },
              })
            }
          />
          . year-old{" "}
          <SelectFieldComponent
            field={templateFields.race}
            fieldName="race"
            onClick={() =>
              setTemplateFields({
                ...templateFields,
                race: { ...templateFields.race, active: true },
              })
            }
          />
          {templateFields.male.active ? (
            renderField("male")
          ) : (
            <SelectFieldComponent
              field={templateFields.male}
              fieldName="male"
              onClick={() =>
                setTemplateFields({
                  ...templateFields,
                  male: { ...templateFields.male, active: true },
                })
              }
            />
          )}
          with chronic pain syndrome presents for Choose an item.. Patient is
          right hand dominant. Currently, retired .
        </span>
      </div>
    </div>
  );
};

export default TemplateTwo;
