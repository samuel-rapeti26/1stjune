import React, { useState } from "react";
import { Modal } from "../components/common/modal";

import { api } from "../api/AxiosManager";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

const ChangePassword = ({ userId }) => {
  const navigate = useNavigate();

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changeResultModal, setChangeResultModal] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");
  const onResetClick = async () => {
    try {
      setNotificationMessage("");

      const result = await api.post("/changepass", {
        User: userId,
        New_Password: confirmPassword,
      });
      if (result?.data?.password_change) {
        setNotificationMessage("Password changed successfully");
      } else {
        setNotificationMessage(result.data.message);
      }
      setChangeResultModal(true);
    } catch (e) {
      setChangeResultModal(true);
      setNotificationMessage("Something went wrong");
    }
  };
  return (
    <div className="flex flex-col bg-white rounded shadow-lg p-12 mt-6 gap-4">
      <Modal
        modalId=""
        open={changeResultModal}
        setOpen={() => setChangeResultModal(false)}
        title=""
        size="sm"
        escape
        content={
          <div className="flex flex-col gap-4 items-center justify-center">
            <h2 className="text-4xl font-semibold text-gray-500 text-uppercase">
              {notificationMessage}
            </h2>

            <div className="flex justify-end gap-2">
              <Button
                size="small"
                variant="contained"
                color="warning"
                onClick={() => {
                  setChangeResultModal(false);
                  if (notificationMessage === "Password changed successfully") {
                    navigate("/");
                  }
                }}
              >
                OK
              </Button>
            </div>
          </div>
        }
      />
      <div className="flex flex-col gap-2">
        <label className="font-semibold text-sm" htmlFor="newPwdField">
          New password
        </label>
        <input
          className="flex items-center h-12 px-4 w-64 bg-gray-200 rounded focus:outline-none focus:ring-1 focus:shadow-md"
          type="password"
          name="newPwdField"
          id="newPwdField"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
      </div>
      <div className="flex flex-col gap-2">
        <label className="font-semibold text-sm" htmlFor="confirmPwdField">
          Confirm password
        </label>
        <input
          className="flex items-center h-12 px-4 w-64 bg-gray-200 rounded focus:outline-none focus:ring-1 focus:shadow-md"
          type="password"
          name="confirmPwdField"
          id="confirmPwdField"
          value={confirmPassword}
          onChange={(e) => {
            setConfirmPassword(e.target.value);
          }}
        />
      </div>

      <button
        className="cursor-pointer flex items-center justify-center h-12 px-6 w-64 bg-blue-600 mt-2 rounded font-semibold text-sm text-blue-100 hover:bg-blue-700"
        onClick={onResetClick}
      >
        Reset
      </button>
    </div>
  );
};

export default ChangePassword;
